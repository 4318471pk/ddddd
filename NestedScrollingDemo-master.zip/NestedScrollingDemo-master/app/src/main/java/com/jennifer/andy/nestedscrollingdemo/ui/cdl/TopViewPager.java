package com.jennifer.andy.nestedscrollingdemo.ui.cdl;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

public class TopViewPager extends ViewPager {

    OnTouchExListener onTouchExListener;
    public TopViewPager(Context context) {
        super(context);
    }

    public TopViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setOnTouchExListener(OnTouchExListener onTouchExListener) {
        this.onTouchExListener = onTouchExListener;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if(onTouchExListener!=null)
        {
            onTouchExListener.onTouch(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    public interface OnTouchExListener
    {
        void onTouch(MotionEvent ev);
    }
}
