package com.jennifer.andy.nestedscrollingdemo.ui.cdl;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.jennifer.andy.nestedscrollingdemo.R;
import com.jennifer.andy.nestedscrollingdemo.view.BouncingNestedScrollView;
import com.jennifer.andy.nestedscrollingdemo.view.PullZoomScrollView;

public class TTTActivity  extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_tt);

        ViewPager2 vp2=findViewById(R.id.vp2);
        vp2.setOrientation(ViewPager2.ORIENTATION_VERTICAL);
        LayoutInflater layoutInflater=getLayoutInflater();
        vp2.setOffscreenPageLimit(1);


        int kll[]=new int[]{1,2,3,4,5};

        vp2.setAdapter(new FragmentStateAdapter(this) {
            @Override
            public Fragment createFragment(int position) {
                int realPoi=(position-(Integer.MAX_VALUE/2))%kll.length;
                if(realPoi<0)
                {
                    realPoi=realPoi+kll.length;
                }
                return TestFragment.getInstance(realPoi);
            }

            @Override
            public int getItemCount() {
                return Integer.MAX_VALUE;
            }
        });



        vp2.setCurrentItem(Integer.MAX_VALUE/2,false);

    }
}
