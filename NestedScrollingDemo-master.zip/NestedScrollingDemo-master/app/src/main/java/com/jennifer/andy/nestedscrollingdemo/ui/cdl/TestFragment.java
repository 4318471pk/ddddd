package com.jennifer.andy.nestedscrollingdemo.ui.cdl;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import com.jennifer.andy.nestedscrollingdemo.R;

import static android.view.View.OVER_SCROLL_NEVER;

public class TestFragment extends Fragment {

    int index;
    TopViewPager view_pager2;

    public static TestFragment getInstance(int index) {
        TestFragment testFragment = new TestFragment();
        testFragment.index = index;
        return testFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_test, container, false);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView textView = getView().findViewById(R.id.tv);
        textView.setText(" " + index);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("VVVVV", "textView");
            }
        });


        view_pager2 = getView().findViewById(R.id.view_pager2);
        view_pager2.setOverScrollMode(OVER_SCROLL_NEVER);
        view_pager2.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() {
                return 2;
            }

            @Override
            public boolean isViewFromObject(View view, Object object) {
                return view.equals(object);
            }

            public Object instantiateItem(ViewGroup container, int position) {
                if (position == 1) {
                    ImageView imageView = new ImageView(getActivity());
                    imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    imageView.setImageDrawable(getResources().getDrawable(R.mipmap.cat));
                    imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                    imageView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.e("VVVVV","imageView");
                        }
                    });
                    container.addView(imageView);
                    return imageView;
                }
                return null;
            }
        });

        view_pager2.setCurrentItem(1);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("onDestroy", index + " ");
    }
}
