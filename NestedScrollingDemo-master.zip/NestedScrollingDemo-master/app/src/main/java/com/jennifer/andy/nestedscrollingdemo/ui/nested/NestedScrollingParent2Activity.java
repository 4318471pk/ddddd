package com.jennifer.andy.nestedscrollingdemo.ui.nested;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.google.android.material.tabs.TabLayout;
import com.jennifer.andy.nestedscrollingdemo.R;
import com.jennifer.andy.nestedscrollingdemo.adapter.BaseFragmentItemAdapter;
import com.jennifer.andy.nestedscrollingdemo.ui.TabFragment;
import com.jennifer.andy.nestedscrollingdemo.view.BouncingNestedScrollView;

import java.util.ArrayList;
import java.util.List;

/**
 * Author:  andy.xwt
 * Date:    2018/8/8 13:56
 * Description:使用NestedScrollingParent2的实现嵌套滑动
 */

public class NestedScrollingParent2Activity extends AppCompatActivity {

    private TabLayout mTabLayout;
    private NestedScrollView mViewPager;

    public static final int FRAGMENT_COUNT = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nested_srolling_parent2);
        findView();
//        initData();
    }

    private void findView() {
//        mTabLayout = findViewById(R.id.tab_layout);
//        mViewPager = findViewById(R.id.view_pager);
//        mViewPager.setEnableOverScrollBounce(true);
//        mViewPager.setEnableRefresh(false);
//        mViewPager.setEnableLoadMore(true);
    }

//    private void initData() {
//        mViewPager.setAdapter(new BaseFragmentItemAdapter(getSupportFragmentManager(), initFragments(), initTitles()));
//        mViewPager.setOffscreenPageLimit(FRAGMENT_COUNT);
//        mTabLayout.setupWithViewPager(mViewPager);
//    }
//
//    private List<Fragment> initFragments() {
//        List<Fragment> fragments = new ArrayList<>();
//        for (int i = 0; i < FRAGMENT_COUNT; i++) {
//            fragments.add(TabFragment.newInstance("实现NestedScrollingParent2接口"));
//        }
//        return fragments;
//    }
//
//    private List<String> initTitles() {
//        List<String> titles = new ArrayList<>();
//        titles.add("首页");
//        titles.add("全部");
//        titles.add("作者");
//        titles.add("专辑");
//        return titles;
//    }
}
